package com.example.android.libgdxgame;

import android.graphics.Color;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.igalata.bubblepicker.BubblePickerListener;
import com.igalata.bubblepicker.model.PickerItem;
import com.igalata.bubblepicker.rendering.BubblePicker;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    BubblePicker bubblePicker;
    TextView cd;
  static   int total=0;
    String[] name={
            "5",
            "10",
            "15"
    };
    int[] images = {
            R.drawable.red,
            R.drawable.blue,
            R.drawable.black

    };
    int[] colors={
            Color.parseColor("#FF0000"),
            Color.parseColor("#336600"),
            Color.parseColor("#FFFAF0")


    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bubblePicker = findViewById(R.id.bubble);
        cd=(TextView)findViewById(R.id.tv) ;
        ArrayList<PickerItem> listItems = new ArrayList<>();
        for(int i = 0; i<name.length;i++)
        {
            PickerItem item = new PickerItem(name[i], colors[i], Color.BLACK,getDrawable(images[i]));
            listItems.add(item);
        }
        bubblePicker.setItems(listItems);
        bubblePicker.setListener(new BubblePickerListener() {
            @Override
            public void onBubbleSelected(PickerItem pickerItem) {
                Toast.makeText(getApplicationContext(),""+pickerItem.getTitle()+"+", Toast.LENGTH_SHORT).show();

                total+=Integer.parseInt(pickerItem.getTitle());
            }

            @Override
            public void onBubbleDeselected(PickerItem pickerItem) {
                Toast.makeText(getApplicationContext(), ""+pickerItem.getTitle()+"+", Toast.LENGTH_SHORT).show();
                total+=Integer.parseInt(pickerItem.getTitle());
            }
        });
    }


    public void btn(View view) {



            new CountDownTimer(30* 1000+1000, 1000) {

                public void onTick(long millisUntilFinished) {
                    int seconds = (int) (millisUntilFinished / 1000);
                    int minutes = seconds / 60;
                    seconds = seconds % 60;
                    cd.setText("TIMER : " + String.format("%02d", minutes)
                            + ":" + String.format("%02d", seconds));
                }

                public void onFinish() {
                    cd.setText("Completed: Your score is "+total);
                    total=0;
                }
            }.start();

    }
}
