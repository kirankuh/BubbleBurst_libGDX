# LibGDXgame_Assignment
This is a basic libGDX game for Android where the user has to burst bubbles to add points. Here the bubbles are of 3 different colors, each providing 5, 10, 15 points. 

## Development Language Used:

- [x] JAVA
- [x] XML

## Image of LibGDXgame Potrait mode


<img src="app/src/main/res/drawable/WhatsApp Image 2018-06-28 at 10.17.56 PM.jpeg" width="250" height="400">
